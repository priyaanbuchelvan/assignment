
public interface Bank_Account {
	
	public void Create_Account();
	public void Delete_Account();
	public void Update_Account();
	public void Display_Account_Details();

}

